package com.sabbpe.auth;

import com.sabbpe.auth.dto.LoginRequest;
import com.sabbpe.auth.services.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MyLoginTest {

    @Autowired
    private AuthService authService;

    @Test
    public void testLogin() {
        LoginRequest request = new LoginRequest();
        request.setIdentifier("test@test.com");
        request.setPassword("password");
        try {
            authService.login(request);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
