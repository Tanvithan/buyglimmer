package com.sabbpe.auth;

import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class SchemaTest {

    @Test
    public void dumpSchema() {
        String url = "jdbc:mariadb://66.116.197.179:7306/sabbpeapparels";
        String user = "sbuser";
        String password = "KMmTKeK7yh77odw51gK12f";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM customer LIMIT 1")) {

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            System.out.println("SCHEMA FOR sabbpeapparels.customer:");
            for (int i = 1; i <= columnCount; i++) {
                System.out.println(rsmd.getColumnName(i) + " - " + rsmd.getColumnTypeName(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
