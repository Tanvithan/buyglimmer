package com.sabbpe.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PasswordResetTokenValidationResponse {
    private String status;
    private String message;
}
