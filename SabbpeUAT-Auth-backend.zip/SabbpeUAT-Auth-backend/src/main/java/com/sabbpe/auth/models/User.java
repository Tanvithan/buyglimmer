package com.sabbpe.auth.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "customer")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "name", length = 150)
    private String name;

    @Column(name = "email", length = 150, unique = true)
    private String email;

    @Column(name = "mobile", length = 15, unique = true)
    private String mobile;

    @Column(name = "password_hash", length = 255)
    private String password;

    @Column(name = "status")
    private Integer status;

    @Column(name = "meta", columnDefinition = "LONGTEXT")
    private String meta;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
