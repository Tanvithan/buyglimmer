package com.sabbpe.auth.services;

import com.sabbpe.auth.dto.AuthResponse;
import com.sabbpe.auth.dto.LoginRequest;
import com.sabbpe.auth.dto.SignupRequest;
import com.sabbpe.auth.dto.UserInfo;
import com.sabbpe.auth.models.User;
import com.sabbpe.auth.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthResponse register(SignupRequest request) {
        if (request.getEmail() == null && request.getMobile() == null) {
            throw new IllegalArgumentException("Either email or mobile is required");
        }
        
        if (request.getEmail() != null && userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }
        
        if (request.getMobile() != null && userRepository.existsByMobile(request.getMobile())) {
            throw new IllegalArgumentException("Mobile already exists");
        }

        User user = new User();
        user.setId(UUID.randomUUID().toString());
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setMobile(request.getMobile());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setStatus(1); // ACTIVE
        user.setCreatedAt(LocalDateTime.now());

        userRepository.save(user);

        String token = jwtService.generateToken(user);
        UserInfo userInfo = new UserInfo(user.getId(), user.getName(), user.getEmail(), user.getMobile(), null);
        return new AuthResponse(true, token, "User registered successfully", userInfo);
    }

    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByIdentifier(request.getIdentifier())
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException("Invalid credentials");
        }

        if (user.getStatus() != null && user.getStatus() != 1) {
            throw new IllegalArgumentException("Invalid credentials");
        }

        String token = jwtService.generateToken(user);
        UserInfo userInfo = new UserInfo(user.getId(), user.getName(), user.getEmail(), user.getMobile(), null);
        return new AuthResponse(true, token, "Login successful", userInfo);
    }
}
