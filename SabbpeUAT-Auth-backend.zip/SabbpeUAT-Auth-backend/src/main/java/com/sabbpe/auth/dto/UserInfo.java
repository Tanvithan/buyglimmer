package com.sabbpe.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo{
    private String id;
    private String name;
    private String email;
    private String mobile;
    private String clientId;
}