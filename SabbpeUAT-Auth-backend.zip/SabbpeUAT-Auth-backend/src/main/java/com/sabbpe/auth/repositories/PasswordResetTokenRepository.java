package com.sabbpe.auth.repositories;

import com.sabbpe.auth.models.PasswordResetToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, String> {
    PasswordResetToken findByToken(String token);

    PasswordResetToken findFirstByClientIdAndIsUsedTrueOrderByUpdatedAtDesc(String clientId);

}
