-- client_profile: database rules for OTP-only auth
-- Run manually or via your migration tool. If a constraint already exists, skip that statement.
--
-- Rules:
--   - client_mobile UNIQUE (required)
--   - client_email UNIQUE (optional: comment out section 2 if not wanted)
--   - No password requirement (column nullable or drop it)
--   - json_web_token kept for logout; no change needed

-- 1. Make client_mobile UNIQUE (required)
ALTER TABLE client_profile ADD CONSTRAINT uk_client_mobile UNIQUE (client_mobile);

-- 2. Optionally make client_email UNIQUE (comment out next line to skip)
ALTER TABLE client_profile ADD CONSTRAINT uk_client_email UNIQUE (client_email);

-- 3. Remove password requirement: make column nullable (OTP-only users have no password)
ALTER TABLE client_profile MODIFY client_password VARCHAR(255) NULL;
